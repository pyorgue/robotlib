#include "sound.h"

Buzzer::Buzzer(int pin)
{
	_pin = pin;
	tone(8, 100, 1);
}

/**
* \brief Play a note
* \param note The note frequency
* \param duration in milliseconds
*/
void Buzzer::playNote(float note, float duration) const
{
	int x;
	// Convert the frequency to microseconds
	float microsecondsPerWave = 1000000 / note;
	// Calculate how many milliseconds there are per HIGH/LOW cycles.
	float millisecondsPerCycle = 1000 / (microsecondsPerWave * 2);
	// Multiply noteDuration * number or cycles per millisecond
	float loopTime = duration * millisecondsPerCycle;
	// Play the note for the calculated loopTime.
	for (x = 0; x < loopTime; x++)
	{
		digitalWrite(_pin, HIGH);
		delayMicroseconds(microsecondsPerWave);
		digitalWrite(_pin, LOW);
		delayMicroseconds(microsecondsPerWave);
	}
}

void Buzzer::playNote2(float note, float duration) const
{
	tone(_pin, note, duration);
	delay(1 + duration);
}

/**
* \brief Play R2 D2 song
*/
void Buzzer::playR2D2() const
{
	playNote(LA7, 100); //A
	playNote(G7, 100); //G
	playNote(E7, 100); //E
	playNote(C7, 100); //C
	playNote(D7, 100); //D
	playNote(B7, 100); //B
	playNote(F7, 100); //F
	playNote(C8, 100); //C
	playNote(LA7, 100); //A
	playNote(G7, 100); //G
	playNote(E7, 100); //E
	playNote(C7, 100); //C
	playNote(D7, 100); //D
	playNote(B7, 100); //B
	playNote(F7, 100); //F
	playNote(C8, 100); //C
}

void Buzzer::playSound(int* melody, int sizeMelody) const
{
	for (int note = 0; note < sizeMelody; note++){
		playNote2(melody[note], 100);
	}
}

/**
* \brief Play R2 D2 song
*/
void Buzzer::play2R2D2() const
{
	int r2d2[] = { LA7, G7, E7, C7, D7, B7, F7, C8, LA7, G7, E7, C7, D7, B7, F7, C8 };
	playSound(r2d2, sizeof(r2d2) / sizeof(*r2d2));
}

/**
* \brief Play R2 D2 song
*/
void Buzzer::playAriel() const
{
	playNote2(1047, 300); //C
	delay(50);
	playNote2(1175, 300); //D
	delay(50);
	playNote2(1245, 600); //D#
	delay(250);

	playNote2(1175, 300); //D
	delay(50);
	playNote2(1245, 300); //D#
	delay(50);
	playNote2(1397, 600); //F
	delay(250);

	playNote2(1047, 300); //C
	delay(50);
	playNote2(1175, 300); //D
	delay(50);
	playNote2(1245, 500); //D#
	delay(50);
	playNote2(1175, 300); //D
	delay(50);
	playNote2(1245, 300); //D#
	delay(50);
	playNote2(1175, 300); //D
	delay(50);
	playNote2(1245, 300); //D#
	delay(50);
	playNote2(1397, 600); //F
	delay(50);
}



/*
*
* void closeEncounters() {
beep(speakerPin,932,300); //B b
delay(50);
beep(speakerPin,1047,300); //C
delay(50);
beep(speakerPin,831,300); //A b
delay(50);
beep(speakerPin,415,300); //A b
delay(50);
beep(speakerPin,622,500); //E b
delay(500);

beep(speakerPin,466,300); //B b
delay(100);
beep(speakerPin,524,300); //C
delay(100);
beep(speakerPin,415,300); //A b
delay(100);
beep(speakerPin,208,300); //A b
delay(100);
beep(speakerPin,311,500); //E b
delay(500);

beep(speakerPin,233,300); //B b
delay(200);
beep(speakerPin,262,300); //C
delay(200);
beep(speakerPin,208,300); //A b
delay(500);
beep(speakerPin,104,300); //A bp
delay(550);
beep(speakerPin,156,500); //E b
}


void bonk() {
beep(speakerPin,125,500); //C
delay(100);
uhoh();
}

void uhoh() {
beep(speakerPin,415,100); //C
delay(80);
beep(speakerPin,279,100); //C
delay(80);
}

void squeak() {
for (int i=100; i<3000; i=i*1.05) {
beep(speakerPin,i,20);
}
delay(10);
for (int i=100; i<200; i=i*1.15) {
beep(speakerPin,i,60);
}
for (int i=400; i>100; i=i*.85) {
beep(speakerPin,i,60);
}
for (int i = 100; i<5000; i = i*1.45) {
beep(speakerPin, i, 60);
}
delay(10);
for (int i = 100; i<6000; i = i*1.5) {
beep(speakerPin, i, 20);
}
}

void waka() {
for (int i = 1000; i<3000; i = i*1.05) {
beep(speakerPin, i, 10);
}
delay(100);
for (int i = 2000; i>1000; i = i*.95) {
beep(speakerPin, i, 10);
}
for (int i = 1000; i<3000; i = i*1.05) {
beep(speakerPin, i, 10);
}
delay(100);
for (int i = 2000; i>1000; i = i*.95) {
beep(speakerPin, i, 10);
}
for (int i = 1000; i<3000; i = i*1.05) {
beep(speakerPin, i, 10);
}
delay(100);
for (int i = 2000; i>1000; i = i*.95) {
beep(speakerPin, i, 10);
}
for (int i = 1000; i<3000; i = i*1.05) {
beep(speakerPin, i, 10);
}
delay(100);
for (int i = 2000; i>1000; i = i*.95) {
beep(speakerPin, i, 10);
}
}

void catcall() {
for (int i = 1000; i<5000; i = i*1.05) {
beep(speakerPin, i, 10);
}
delay(300);

for (int i = 1000; i<3000; i = i*1.03) {
beep(speakerPin, i, 10);
}
for (int i = 3000; i>1000; i = i*.97) {
beep(speakerPin, i, 10);
}
}

void ohhh() {
for (int i = 1000; i<2000; i = i*1.02) {
beep(speakerPin, i, 10);
}
for (int i = 2000; i>1000; i = i*.98) {
beep(speakerPin, i, 10);
}
}

*/
