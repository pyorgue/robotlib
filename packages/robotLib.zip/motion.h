// motion.h

#ifndef _MOTION_h
#define _MOTION_h

#if defined(ARDUINO) && ARDUINO >= 100
#include "arduino.h"
#else
#include "WProgram.h"
#endif

class Servo;


class Neck{
public:
	Neck(int pin, int turnInterval);
	void attach();
	void turnRight();
	void turnLeft();
	void turnCenter();
private:
	int _pin;
	Servo *_servo;
	int _turnInterval;
	int _position;
	void turn(int angle);
};

#endif

