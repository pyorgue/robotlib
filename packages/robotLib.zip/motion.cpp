#include "motion.h"
#include "Servo.h"


Neck::Neck(int pin, int turnInterval){
	_pin = pin;
	_turnInterval = turnInterval;
	_position = 0;
	_servo = new Servo();
}

void Neck::attach(){
	_servo->attach(_pin);
	_servo->write(90);
	_position = 90;
}

void Neck::turn(int angle){
	int pos;
	int way = 1;
	if (_position >= angle){
		way = -1;
	}
	for (pos = _position; way == -1 ? pos >= angle : pos <= angle; pos += (1 * way))
	{
		_servo->write(pos);
		delay(_turnInterval);
	}
	_position = angle;
}

void Neck::turnLeft(){
	turn(45);
}

void Neck::turnRight(){
	turn(135);
}

void Neck::turnCenter(){
	turn(90);
}